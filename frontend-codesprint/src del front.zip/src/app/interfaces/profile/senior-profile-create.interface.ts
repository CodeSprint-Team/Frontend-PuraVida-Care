export interface SeniorProfileCreateRequest {
  userId: number;
  carePreference?: string;
  emergencyContactName?: string;
  emergencyContactPhone?: string;
  healthObservation?: string;
  mobilityNotes?: string;
}