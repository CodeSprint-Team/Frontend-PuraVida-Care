export interface ClientProfileCreateRequest {
  userId: number;
  phone: string;
  notes?: string;
}